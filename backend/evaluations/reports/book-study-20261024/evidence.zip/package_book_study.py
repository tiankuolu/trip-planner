import hashlib
import importlib.metadata
import json
import platform
import zipfile
from pathlib import Path

root = Path("evaluations/reports/book-study-20261024")
source = json.loads((root / "trial/source.json").read_text(encoding="utf-8"))
manifest = json.loads((root / "trial/manifest.json").read_text(encoding="utf-8"))
for name, expected in [("benchmark", manifest["benchmark_hash"]), ("snapshot", manifest["snapshot_hash"]), ("source", manifest["source_hash"])]:
    content = json.loads((root / f"trial/{name}.json").read_text(encoding="utf-8"))
    observed = hashlib.sha256(json.dumps(content, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    if observed != expected:
        raise ValueError(f"实验文件校验失败：{name}")
environment = {"python": platform.python_version(), "platform": platform.platform(),
               "dependencies": {name: importlib.metadata.version(name)
                                for name in ["numpy", "scipy", "openai", "httpx", "pydantic", "jsonschema", "pytest", "ruff"]}}
(root / "environment.json").write_text(json.dumps(environment, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
locked = sorted(f"{distribution.metadata['Name']}=={distribution.version}" for distribution in importlib.metadata.distributions())
(root / "requirements-lock.txt").write_text("\n".join(locked) + "\n", encoding="utf-8")
archive = root / "evidence.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as target:
    for name, content in source.items():
        target.writestr(f"code/{name}", content)
    target.write("requirements.txt", "code/requirements.txt")
    target.write("evaluations/book_methods_research.md", "code/evaluations/book_methods_research.md")
    for file in sorted(root.rglob("*")):
        include = file.suffix not in {".zip", ".html"} or file.name == "explainer.html"
        if file.is_file() and file != archive and file.name != "evidence-sha256.txt" and include:
            target.write(file, file.relative_to(root).as_posix())
    target.write("evaluations/reports/2026-10-23-full/evidence.zip", "historical-evidence.zip")
    target.write(__file__, "package_book_study.py")
checksum = hashlib.sha256(archive.read_bytes()).hexdigest()
(root / "evidence-sha256.txt").write_text(checksum + "  evidence.zip\n", encoding="utf-8")
print({"archive": str(archive), "bytes": archive.stat().st_size, "sha256": checksum})
